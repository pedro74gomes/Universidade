import imaplib
import email
import quopri
import re
import email.utils
import threading
import time
import datetime
from webbrowser import BackgroundBrowser
import mysql.connector
import slack_sdk
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from datetime import datetime
import sys
import itertools
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import re

all_text = ""
done = False
def animate():
    sys.stdout.write('\n')
    for c in itertools.cycle(['   ','.  ','.. ','...']):
        if done:
            break
        sys.stdout.write('\rBase de dados a atualizar' + c)
        sys.stdout.flush()
        time.sleep(0.5)

t = threading.Thread(target=animate)
t.start()

mydb = mysql.connector.connect(
  host="localhost",
  user="usertest",
  password="Projeto2023",
  database="quantifiedself",
  connection_timeout=10
)

mycursor = mydb.cursor()

#Abrir um arquivo de texto para gravar as declarações SQL INSERT
#EMAIL
#print("\n-------------------------------- EMAIL --------------------------------\n")

with imaplib.IMAP4_SSL(host="imap.gmail.com", port=imaplib.IMAP4_SSL_PORT) as imap:

    imap.login("mokinmooo@gmail.com", "unsbnvpxvegfzkue") #email, password

    imap.select("inbox")

    _, email_ids = imap.search(None, "ALL")
    
    for email_id in email_ids[0].decode().split():

        #print("-------------------------------- Start of Email {} ------------------------------".format(email_id))

        _, email_data = imap.fetch(email_id, '(RFC822)')
        message = email.message_from_bytes(email_data[0][1])

        #remove weird chars 
        start = '=?UTF-8?Q?'
        end = '?'

        #from
        f = quopri.decodestring("{}".format(message.get("From"))).decode('utf-8')
        ff = re.search('<(.*)>', f)
        if start in f: f = f[f.find(start)+len(start):f.rfind(end)].replace('_',' ') + ' <' + ff.group(1) + '>'
        #print('From: ' + f)
        fe = ff.group(1) #email
        fn = re.search('(.*)<',f).group(1)

        #to
        t = quopri.decodestring("{}".format(message.get("To"))).decode('utf-8')
        #print("To: " + t)

        #bcc
        bc = quopri.decodestring("{}".format(message.get("Bcc"))).decode('utf-8')
        #print('Bcc: ' + bc)

        #date
        d = quopri.decodestring("{}".format(message.get("Date"))).decode('utf-8')
        tempo = re.search(r'\d{2}:\d{2}:\d{2}', d).group(0)
        d = email.utils.parsedate(str(d))
        d = str(d[0]) + '-' + str(d[1]) + '-' + str(d[2]) + ' ' + tempo
        d = '-'.join(i.zfill(2) for i in d.split('-'))
        #print('Date: ' + d)

        #subject
        s = quopri.decodestring("{}".format(message.get("Subject"))).decode('utf-8')
        if start in s: s = s[s.find(start)+len(start):s.rfind(end)].replace('_',' ')
        #print('Subject: ' + s)

        #body
        #print('Body: ', end = '')
        for part in message.walk():
            if part.get_content_type() == "text/plain":
              bd = quopri.decodestring(part.get_payload(decode=True)).decode('utf-8', errors = 'ignore').strip()
              all_text += " " + bd
              #print(bd)

        #Gravar uma declaração SQL INSERT no arquivo de texto
        id = 1

        add_or_update_contacto = ("INSERT INTO Contacto (Endereco, Nome) "
                          "VALUES (%s, %s) "
                          "ON DUPLICATE KEY UPDATE Nome = %s")

        data_contacto = (fe, fn, fn)

        mycursor.execute(add_or_update_contacto, data_contacto)

        add_or_update_mensagem_email = ("INSERT INTO Mensagem (idMensagem, Nome, Bcc, Data, Subject, Body, Channel, idUtilizador, Endereco) "
                                        "VALUES (%s, %s, %s, %s, %s, %s, NULL, %s, %s) "
                                        "ON DUPLICATE KEY UPDATE Nome = %s, Bcc = %s, Data = %s, Subject = %s, Body = %s, Channel = NULL, idUtilizador = %s, Endereco = %s")

        data_mensagem_email = (email_id, fn, bc, d, s, bd, id, fe,
                              fn, bc, d, s, bd,id , fe)

        mycursor.execute(add_or_update_mensagem_email,data_mensagem_email)

        #print("-------------------------------- End of Email {} --------------------------------\n".format(email_id))

mydb.commit()
#if mycursor.rowcount > 0: print("novo(s) email(s) inserido(s)")
#print("\n-------------------------------- EMAIL (FIM) --------------------------------\n")

#SLACK
#print("\n-------------------------------- SLACK --------------------------------\n")


client = WebClient(token="xoxp-5147801084357-5150742430370-5150755720803-91c063b12c8fe439d0f458e3bc8686ca")

result = client.conversations_list(types='public_channel,private_channel,im,mpim')
conversations = result['channels']
message_id = int(email_id) + 1

for i, conversation in enumerate(conversations):
    conversation_id = conversation['id']
    result = client.conversations_history(channel=conversation_id)
    messages = result['messages']

    if messages:
        if 'name' in conversation:
            conversation_name = conversation['name']
        else:
            user_id = conversation['user']
            result = client.users_info(user=user_id)
            user = result['user']
            conversation_name = user.get('real_name', user['name'])

        if "deactivated" in conversation_name: continue
        #print(f'canal "{conversation_name}":')

        for message in reversed(messages):
            timestamp = float(message['ts'])
            dt = datetime.fromtimestamp(timestamp)
            formatted_timestamp = dt.strftime('%Y-%m-%d %H:%M:%S')

            user_id = message['user']
            result = client.users_info(user=user_id)
            user = result['user']
            username = user.get('real_name', user['name'])

            if 'email' in user['profile']:
                email = user['profile']['email']
            else:
                email = ''

            body = message['text']
            all_text += " " + body
            
            id = 1
            
            if email != "mokinmooo@gmail.com":
                #print(f'{message_id} - {formatted_timestamp} {username} <{email}>: {body}')

                #Gravar uma declaração SQL INSERT no arquivo de texto
                add_or_update_contacto = ("INSERT INTO Contacto (Endereco, Nome) "
                                            "VALUES (%s, %s) "
                                            "ON DUPLICATE KEY UPDATE Nome = %s")

                data_contacto = (email, username, 
                                username)

                mycursor.execute(add_or_update_contacto, data_contacto)

                add_or_update_mensagem_slack = ("INSERT INTO Mensagem (idMensagem, Nome, Data, Channel, Body, idUtilizador, Endereco) "
                                                "VALUES (%s, %s, %s, %s, %s, %s, %s) "
                                                "ON DUPLICATE KEY UPDATE Nome = %s, Data = %s, Channel = %s, Body = %s, idUtilizador = %s, Endereco = %s")

                data_mensagem_slack = (message_id, username, formatted_timestamp, conversation_name, body, id, email, 
                                        username, formatted_timestamp, conversation_name, body, id, email)

                mycursor.execute(add_or_update_mensagem_slack,data_mensagem_slack)
                message_id +=1
            #print('\n')
mydb.commit()

#print("\n-------------------------------- SLACK (FIM) --------------------------------\n")

def ultimo_contacto():
    query = "SELECT MAX(data) as 'último contacto', nome FROM mensagem GROUP BY nome ORDER BY data;"

    mycursor = mydb.cursor()
    mycursor.execute(query)

    print("\n--------------------------------------------------------------")
    for (data, nome) in mycursor:
        print(f"{nome:<25} {str(data):<19}")
    print("--------------------------------------------------------------")

    mycursor.close()

def emails_hoje():
    query = "SELECT nome, data, subject, body, endereco FROM mensagem where (DATE(Data) = CURDATE() AND (Channel IS NULL));"

    mycursor = mydb.cursor()
    mycursor.execute(query)
    i = 1
    for (nome, data, subject, body, endereco) in mycursor:
        print("\n-------------------------------- Start of Email {} ------------------------------".format(str(i)))
        print(f"From: {nome} <{endereco}>\nData: {data}\nSubject: {subject}\n\nBody: {body}")
        print("-------------------------------- End of Email {} ------------------------------".format(str(i)))
        i+=1

    mycursor.close()

def n_MensagensRecebidas():
    query = "SELECT nome, COUNT(idMensagem) as nMensagensRecebidas FROM mensagem GROUP BY nome;"

    mycursor = mydb.cursor()
    mycursor.execute(query)

    print("\n--------------------------------------------------------------")
    for (nome, nMensagensRecebidas) in mycursor:
        print(f"{nome:<25} {nMensagensRecebidas:<5}")
    print("--------------------------------------------------------------")

    mycursor.close()

done = True
print("\nBase de dados atualizada com sucesso!")

def createWordCloud():
    mask = np.array(Image.open("cloud.png"))
    wordcloud = WordCloud(width=1920, height=1080, colormap="turbo", max_font_size = 320, mask = mask, contour_width = 3, contour_color = "steelblue").generate(all_text)
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis("off")
    plt.show() 
    wordcloud.to_file("wordcloud.png")

def createWCcontacto(num):
    text = ""
    mask = np.array(Image.open("cloud.png"))

    query = "SELECT body FROM mensagem JOIN contacto ON mensagem.nome = contacto.nome WHERE contacto.endereco = (SELECT endereco FROM contacto LIMIT {}, 1);".format(num)

    mycursor = mydb.cursor()
    mycursor.execute(query)
    for (body) in mycursor:
      text += " " + str(body)
        
    wordcloud = WordCloud(width=1920, height=1080, colormap="turbo", max_font_size = 320, mask = mask, contour_width = 3, contour_color = "steelblue").generate(text)
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis("off")
    plt.show() 
    wordcloud.to_file("WCcontactos.png")

def contacto():
    query = "SELECT nome FROM contacto GROUP BY nome;"

    mycursor = mydb.cursor()
    mycursor.execute(query)
    i=0
    print("\n--------------------------------------------------------------")
    for (nome) in mycursor:
        nome = str(nome)
        nome = re.sub(r"[(),']",'',nome)
        print(f"{i} - {nome}")
        i+=1
    print("--------------------------------------------------------------")

    mycursor.close()

def contactos():
    query = "SELECT * FROM contacto;"

    mycursor = mydb.cursor()
    mycursor.execute(query)

    print("\n--------------------------------------------------------------")
    for (email, nome) in mycursor:
        nome = str(nome)
        print(f"{nome:<25} <{email}>")
    print("--------------------------------------------------------------")

    mycursor.close()

def canais():
    query = "SELECT channel, MAX(data) FROM mensagem WHERE channel IS NOT NULL GROUP BY channel;"

    mycursor = mydb.cursor()
    mycursor.execute(query)

    print("\n--------------------------------------------------------------")
    for (canal, data) in mycursor:
        canal = str(canal)
        print(f"{canal:<25} {data}")
    print("--------------------------------------------------------------")

    mycursor.close()

# exibir o menu
# loop para receber a entrada do usuário e executar a opção selecionada
while True:
    print("\nMenu de opções:")
    print("1 - Lista de pessoas e o último contacto com cada uma.")
    print("2 - Apresentar os emails recebidos hoje.")
    print("3 - Lista de pessoas e o número total de mensagens recebidas de cada uma.")
    print("4 - Criar uma WordCloud de todas as mensagens recebidas.")
    print("5 - Criar uma WordCloud com as palavras mais usadas por esse contacto.")
    print("6 - Lista de contactos.")
    print("7 - Lista de canais do slack e data da última mensagem recebida.")
    print("0 - Sair")

    opcao = input("\nDigite a opção desejada: ")
    if opcao == "1":
        ultimo_contacto()
    elif opcao == "2":
        emails_hoje()
    elif opcao == "3":
        n_MensagensRecebidas()
    elif opcao == "4":
        createWordCloud()
    elif opcao == "5":
        contacto()
        num = input("\nDigite o número do contacto: ")
        createWCcontacto(num)
    elif opcao == "6":
        contactos()
    elif opcao == "7":
        canais()
    elif opcao == "0":
        break
    else:
        print("Opção inválida. Por favor, selecione uma opção válida.")
